#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG_FILE="${SCRIPT_DIR}/config.env"

if [ ! -f "$CONFIG_FILE" ]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') [ERROR] 配置文件不存在: $CONFIG_FILE" >&2
  exit 1
fi

# shellcheck source=config.env
source "$CONFIG_FILE"

# 基于脚本所在目录拼接日志路径，确保无论从哪里执行都落在正确位置
LOG_DIR="${SCRIPT_DIR}/${LOG_DIR_REL}"
LOG_FILE="${LOG_DIR}/monitor.log"
ALERT_LOG="${LOG_DIR}/alert.log"

mkdir -p "$LOG_DIR"

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

# ---------- 采集指标 ----------
cpu_idle=$(top -bn1 | grep '%Cpu' | awk '{print $8}')
cpu_usage=$(awk "BEGIN{printf \"%.0f\", 100 - ${cpu_idle}}")

mem_total=$(free -m | awk '/^Mem:/{print $2}')
mem_used=$(free -m | awk '/^Mem:/{print $3}')
mem_usage=0
if [ "$mem_total" -gt 0 ]; then
  mem_usage=$(awk "BEGIN{printf \"%.0f\", ${mem_used}/${mem_total}*100}")
fi

disk_usage=$(df / | awk 'NR==2{gsub(/%/,"",$5);print $5}')

load_avg=$(awk '{print $1}' /proc/loadavg)

# ---------- 写入监控日志 ----------
echo "${TIMESTAMP} HOST=${HOSTNAME_LABEL} CPU=${cpu_usage}% MEM=${mem_usage}% DISK=${disk_usage}% LOAD=${load_avg}" >> "$LOG_FILE"

# ---------- 告警判断 ----------
alerts=()

if [ "$cpu_usage" -gt "$CPU_THRESHOLD" ]; then
  alerts+=("CPU 使用率过高: ${cpu_usage}%")
fi

if [ "$mem_usage" -gt "$MEM_THRESHOLD" ]; then
  alerts+=("内存使用率过高: ${mem_usage}%")
fi

if [ "$disk_usage" -gt "$DISK_THRESHOLD" ]; then
  alerts+=("磁盘使用率过高: ${disk_usage}%")
fi

high_load=$(awk "BEGIN{print (${load_avg} > ${LOAD_THRESHOLD}) ? 1 : 0}")
if [ "$high_load" -eq 1 ]; then
  alerts+=("系统负载过高: ${load_avg}")
fi

# ---------- 发送告警 ----------
if [ "${#alerts[@]}" -gt 0 ] && [ "$ALERT_ENABLE" = true ]; then
  MESSAGE="${TIMESTAMP} [${HOSTNAME_LABEL}] 服务器资源告警:\n"
  for alert in "${alerts[@]}"; do
    MESSAGE="${MESSAGE}- ${alert}\n"
  done

  echo -e "$MESSAGE" >> "$ALERT_LOG"

  if [ "$DINGTALK_ENABLE" = true ] && [ -n "$DINGTALK_WEBHOOK" ]; then
    curl -s -X POST "$DINGTALK_WEBHOOK" \
      -H 'Content-Type: application/json' \
      -d "{\"msgtype\":\"text\",\"text\":{\"content\":\"${MESSAGE}\"}}" >/dev/null 2>&1 || true
  fi

  if [ "$WECOM_ENABLE" = true ] && [ -n "$WECOM_WEBHOOK" ]; then
    curl -s -X POST "$WECOM_WEBHOOK" \
      -H 'Content-Type: application/json' \
      -d "{\"msgtype\":\"text\",\"text\":{\"content\":\"${MESSAGE}\"}}" >/dev/null 2>&1 || true
  fi
fi
