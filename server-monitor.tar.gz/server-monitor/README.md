# Server Monitor

轻量级服务器资源监控告警系统，支持 CPU、内存、磁盘、负载四项指标采集，超阈值自动通过钉钉/企业微信推送告警通知。

## 目录结构

```
server-monitor/
├── config.env          # 配置文件（阈值、告警渠道、日志路径）
├── monitor.sh          # 主监控脚本（采集、判断、告警）
├── crontab.conf        # 定时任务规则
├── logs/
│   ├── monitor.log     # 监控数据日志
│   ├── alert.log       # 告警记录
│   └── cron.log        # 定时任务执行日志
└── README.md           # 本文件
```

## 快速开始

### 1. 手动执行一次

```bash
/bin/bash /home/ubuntu/server-monitor/monitor.sh
```

### 2. 查看监控日志

```bash
cat /home/ubuntu/server-monitor/logs/monitor.log
```

### 3. 配置定时任务

```bash
crontab /home/ubuntu/server-monitor/crontab.conf
crontab -l
```

## 监控指标

| 指标 | 采集方式 | 默认阈值 |
|------|---------|---------|
| CPU 使用率 | `top -bn1` | 80% |
| 内存使用率 | `free -m` | 80% |
| 磁盘使用率 | `df /` | 85% |
| 系统负载 | `/proc/loadavg` | 4.0 |

## 配置说明

编辑 `config.env` 调整参数，保存后下次执行自动生效：

```bash
# 资源阈值
CPU_THRESHOLD=80        # CPU 告警阈值（%）
MEM_THRESHOLD=80        # 内存告警阈值（%）
DISK_THRESHOLD=85       # 磁盘告警阈值（%）
LOAD_THRESHOLD=4.0      # 负载告警阈值

# 告警总开关
ALERT_ENABLE=true

# 钉钉告警
DINGTALK_WEBHOOK=""     # 钉钉机器人 Webhook 地址
DINGTALK_ENABLE=false   # 是否启用

# 企业微信告警
WECOM_WEBHOOK=""        # 企业微信机器人 Webhook 地址
WECOM_ENABLE=false      # 是否启用
```

## 告警渠道

### 钉钉

1. 在钉钉群中添加自定义机器人，获取 Webhook 地址
2. 将地址填入 `config.env` 的 `DINGTALK_WEBHOOK`
3. 设置 `DINGTALK_ENABLE=true`

### 企业微信

1. 在企业微信群中添加群机器人，获取 Webhook 地址
2. 将地址填入 `config.env` 的 `WECOM_WEBHOOK`
3. 设置 `WECOM_ENABLE=true`

两个渠道可同时开启，互不影响。

## 定时任务管理

```bash
# 查看当前定时任务
crontab -l

# 修改执行频率（编辑 crontab.conf 后重新导入）
crontab /home/ubuntu/server-monitor/crontab.conf

# 暂停定时任务
crontab -r

# 查看 cron 执行日志
cat /home/ubuntu/server-monitor/logs/cron.log
```

默认每 20 分钟执行一次，修改 `crontab.conf` 中的 `*/20` 即可调整频率。

## 日志说明

| 日志文件 | 内容 |
|---------|------|
| `logs/monitor.log` | 每次采集的指标数据，格式：`时间 HOST=主机名 CPU=x% MEM=x% DISK=x% LOAD=x` |
| `logs/alert.log` | 触发告警时的详细记录 |
| `logs/cron.log` | 定时任务执行的标准输出和错误信息 |

## 常见问题

**Q: 脚本执行报错 "配置文件不存在"？**

确保 `config.env` 与 `monitor.sh` 在同一目录下，脚本会自动查找同级目录的配置文件。

**Q: 钉钉/企业微信收不到消息？**

检查三个条件：① `ALERT_ENABLE=true` ② 对应渠道的 `_ENABLE=true` ③ `_WEBHOOK` 地址正确且未过期。

**Q: 如何临时关闭所有告警？**

将 `config.env` 中的 `ALERT_ENABLE` 设为 `false`，监控数据仍会正常记录。

**Q: 如何更换部署路径？**

1. 将整个目录复制到新位置
2. 修改 `config.env` 中的 `LOG_DIR`
3. 修改 `crontab.conf` 中的脚本路径
4. 重新导入 crontab
